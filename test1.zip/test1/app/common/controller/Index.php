<?php
    namespace app\common\controller;
    class Index{
        public function index(){
            echo 'dkkk';
        }
        public function ask(){
            echo 'dkddddkk';
        }
    }
?>