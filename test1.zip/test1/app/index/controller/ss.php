<?php
    namespace app\index\controller\ss;
    const Foo = 1;
    
?>