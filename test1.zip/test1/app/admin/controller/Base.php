<?php
namespace app\admin\controller;
class Base
{
    public function index()
    {
       return 'dsddd';
    }
}