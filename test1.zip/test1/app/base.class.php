<?php
namespace app\controller
use Think\Controller;
class base {
    public function ass(){
        return 'dddd';
    }
}
?>