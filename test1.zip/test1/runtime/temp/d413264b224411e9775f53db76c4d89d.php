<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"C:\Users\ZTX\Documents\GitHub\thinkphp\test1\public/../app/index\view\index\index.html";i:1507453045;}*/ ?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div>ssssssss</div>
    <a href="./../signin/index">注册</a>
</body>
</html>