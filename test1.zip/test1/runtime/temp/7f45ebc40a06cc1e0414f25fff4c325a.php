<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"C:\Users\ZTX\Documents\GitHub\thinkphp\test1\public/../app/index\view\base\upload.html";i:1507444911;}*/ ?>
dddd