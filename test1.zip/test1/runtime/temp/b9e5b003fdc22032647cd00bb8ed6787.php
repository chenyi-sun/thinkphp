<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"C:\Users\ZTX\Documents\GitHub\thinkphp\test1\public/../app/index\view\base\view1.html";i:1507444870;}*/ ?>
sss