<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"C:\Users\ZTX\Documents\GitHub\thinkphp\test1\public/../app/index\view\signin\index.html";i:1507527080;}*/ ?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    signinddd
    <br/>
    <?php echo $email; ?>
    <form action="./index.html" method="post">
        <input type="text" name="fname" />
        <input type="submit" value="Submit" />
    </form>
    <p>form</p>
    <p>STATIC</p>
    <p>TT</p>
    <br/>
    <p>__123__</p>
    <p>__JS__</p>
    <p>__CSS__/ss</p>
    <p>__URL__</p>
    <p>__ROOT__</P>
</body>
</html>