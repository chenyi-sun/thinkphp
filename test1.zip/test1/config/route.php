<?php
    return [
        'news/:id' => 'index/base/info'
    ];

?>